﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DentalWebApp.Controllers
{
    public class DirectiveController : Controller
    {
        //
        // GET: /Directive/

        public ActionResult UserMenu()
        {
            return View();
        }
        public ActionResult DataGrid1()
        {
            return View();
        }

        public ActionResult DataGrid2()
        {
            return View();
        }

        public ActionResult DataModal1()
        {
            return View();
        }
    }
}
